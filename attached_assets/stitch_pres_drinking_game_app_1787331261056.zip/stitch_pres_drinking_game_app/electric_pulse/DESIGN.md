---
name: Electric Pulse
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#37393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c2caad'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8c9479'
  outline-variant: '#434933'
  surface-tint: '#a0d800'
  primary: '#ffffff'
  on-primary: '#253600'
  primary-container: '#b7f700'
  on-primary-container: '#506e00'
  inverse-primary: '#4b6700'
  secondary: '#ffb1c3'
  on-secondary: '#66002c'
  secondary-container: '#ff4b89'
  on-secondary-container: '#590026'
  tertiary: '#ffffff'
  on-tertiary: '#002388'
  tertiary-container: '#dde1ff'
  on-tertiary-container: '#1f51f6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b7f700'
  primary-fixed-dim: '#a0d800'
  on-primary-fixed: '#141f00'
  on-primary-fixed-variant: '#374e00'
  secondary-fixed: '#ffd9e0'
  secondary-fixed-dim: '#ffb1c3'
  on-secondary-fixed: '#3f0019'
  on-secondary-fixed-variant: '#8f0041'
  tertiary-fixed: '#dde1ff'
  tertiary-fixed-dim: '#b8c3ff'
  on-tertiary-fixed: '#001356'
  on-tertiary-fixed-variant: '#0035be'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: 0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: 0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  label-bold:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '800'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding-mobile: 24px
  container-padding-desktop: 64px
  gutter: 24px
  element-gap: 16px
---

## Brand & Style

The design system is built on an **Energetic & Playful** narrative, specifically tailored for a high-impact social or presentation environment. It leans heavily into a refined **Neon-Modernist** aesthetic—combining the depth of rich gradients with the friendly accessibility of soft, oversized geometry.

The emotional goal is to feel celebratory and high-motion without the harshness of traditional brutalism. By utilizing "squishy" rounded corners and vibrant accent pops against a deep, immersive background, the UI creates a focused "stage" for content. White space is replaced by "color space," where the deep indigo serves as the grounding canvas for glowing, tactile elements.

## Colors

The palette is dominated by a deep, atmospheric foundation to make the vibrant accents "vibrate" with energy.

- **Primary (Acid Green):** Used for primary actions and high-priority status indicators. It must always be paired with dark text for legibility.
- **Secondary (Hot Pink):** Used for "confetti" details, badges, and secondary highlights.
- **Tertiary (Cobalt Blue):** Used for interactive supportive elements and subtle iconography.
- **Background:** A persistent diagonal gradient from deep indigo to violet-blue. Surface elements should utilize semi-transparent variations of the neutral white to maintain a sense of depth over this gradient.

## Typography

This design system exclusively employs heavy weights to maintain a "chunky" and friendly personality. 

- **Weight Restriction:** Do not use weights below 600 (Semi-Bold). Headlines should stay at 700 or 800.
- **Letter Spacing:** Generous tracking is applied to all levels to ensure legibility against vibrant backgrounds and to enhance the modern, airy feel of the bold type.
- **Hierarchy:** Contrast is achieved through scale and color rather than weight shifts. Use the Primary Acid Green for critical text highlights.

## Layout & Spacing

The layout philosophy follows a **Fluid-Floating** model. Elements are treated as distinct "islands" floating over the background gradient.

- **Grid:** A standard 12-column grid for desktop, but with significantly wide margins (64px) to keep content centered and impactful.
- **Rhythm:** An 8px base unit is used for all padding and margins. 
- **Adaptation:** On mobile, margins reduce to 24px, and the 12-column grid collapses to a single-column stack. Components should retain their large 24px corner radius even on smaller screens to preserve the "pill" aesthetic.

## Elevation & Depth

Depth is communicated through **Soft Luminous Shadows** rather than hard borders.

- **Shadow Profile:** Use large blur radii (30px+) with low-opacity dark indigo tints to create a "floating" effect. Avoid pure black shadows; they should feel like they are occluding the blue light of the background.
- **Surface Treatment:** Cards and containers use a subtle "Glassmorphism" effect—white fill at 10-15% opacity with a high-intensity backdrop blur (20px). This allows the background gradient to peek through while keeping text legible.
- **Interactivity:** On hover, elements should slightly scale up (1.02x) and the shadow spread should increase, simulating physical lift.

## Shapes

The shape language is defined by extreme roundness. 

- **Cards:** Use a fixed 24px corner radius for all primary containers.
- **Buttons & Inputs:** Use a fully "pill-shaped" radius (999px). 
- **Accent Details:** Small decorative elements (confetti or badges) should use either perfect circles or the same 24px radius to maintain visual consistency. 
- **Consistency:** Never use sharp 90-degree corners in this design system.

## Components

- **Buttons:** Large, pill-shaped, and high-contrast. The primary button uses the Acid Green background with a dark indigo label. Secondary buttons use a thick 2px white stroke with no fill.
- **Cards:** Large 24px rounded rectangles. They should feature a subtle 1px inner border (white at 20% opacity) to define the edge against the gradient.
- **Chips/Badges:** Small, pill-shaped, and usually colored in Hot Pink or Cobalt Blue. These are used sparingly as "pops" of color.
- **Input Fields:** Pill-shaped with a translucent white background. The focus state is a 2px Acid Green glow.
- **Progress Bars:** Thick (12px height) with fully rounded caps. The track should be translucent indigo and the indicator should be a gradient of Hot Pink to Acid Green.
- **Lists:** Items are separated by generous vertical gaps (12px) rather than divider lines, emphasizing the "floating island" concept.